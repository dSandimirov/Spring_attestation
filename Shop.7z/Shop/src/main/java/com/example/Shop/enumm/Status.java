package com.example.Shop.enumm;

public enum Status {
    Принят, Оформлен, Ожидает, Получен
}
